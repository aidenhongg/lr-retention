# MUSE-News budget pilot

This pilot measures whether the original-weight rounding probe E(lr) predicts how much forgetting survives FP4 quantization. It uses the pinned MUSE-News 7B target, five learning rates, one seed, and three fixed epochs. A single seed provides preliminary evidence without measuring reproducibility.

The recipe is in `configs/experiment.yaml`. Source documents are partitioned deterministically before tokenization. Validation selects checkpoints; test and quantized measurements begin only after the selection is published. An unavailable match produces curves and an explicit report instead of dropping a learning rate.

All model computation and tests run on RunPod. On the GPU pod, install and validate with `bash runpod/setup.sh`, then execute `bash runpod/run.sh`. The scripts use `/opt/mock-experiment` for source, `/opt/pilot-env` for dependencies, and `/artifacts` for experiment artifacts. The mounted network volume at `/workspace` holds the verified final archive.

Run `python runpod/pod.py guard --state runpod/pilot-main-state.json --poll 30` on the orchestration machine while the pod exists. The guard includes GPU and storage costs, reserves shutdown credit, and checks accrued account spending. The experiment ceiling is $15 including setup; a replacement pod receives only the remaining allowance. Other account workloads can reduce available credit independently.

Records and failed outcomes are immutable JSON files. Training and evaluation errors include tracebacks. Results contain validation curves, frozen selection, raw NLL measurements, predictor records, CSV tables, PNG/SVG figures, and a summary. Small results and logs are copied locally.

Use a fresh artifact root when changing scientific implementation or dependency versions. Keep the source snapshot and exact environment freeze with the results.

After analysis, use `python runpod/archive.py copy --root /artifacts --destination /workspace/muse-news-pilot` on the pod. Verify its manifest before terminating the GPU. The archive retains selected and final weights and the experiment evidence; unselected weights remain disposable. Network-volume storage continues to be billed after GPU teardown.
